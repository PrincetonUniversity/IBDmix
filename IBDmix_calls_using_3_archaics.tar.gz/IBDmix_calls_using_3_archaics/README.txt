This directory contains IBDmix calls on each population from 1000 Genomes Project (phase 3). Altai, Vindija, Chagyrskaya refer to IBDmix calls using Altai, Vindija, and Chagyrskaya as archaic reference, respectively.
A minimum segment size threshold (0.05 cM) and Lod score (4) are used to mitigate false positives.
We used population-specific genetic distance from https://github.com/popgenmethods/pyrho to obtain genetic distance of IBDmix calls.
